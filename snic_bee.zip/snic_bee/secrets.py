# Local-only secrets for snic_bee (DO NOT COMMIT).
# This file is ignored by git via .gitignore.

WIFI_NETWORKS = [
    ("ChinaNet-E5y7", "zadyx5cc"),
    ("Deipss", "aabbccdd"),
    ("ABC", "aabbccdd"),
]

SERVER_IP = "10.94.156.92"
SERVER_PORT = 8080
SERVER_PATH = "/upload"

DEVICE_NAME = "snic_bee"

